package tv.codealong.tutorials.springboot.newboston

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class NewbostonApplication

fun main(args: Array<String>) {
	runApplication<NewbostonApplication>(*args)
}
