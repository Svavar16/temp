package tv.codealong.tutorials.springboot.newboston

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class NewbostonApplicationTests {

	@Test
	fun contextLoads() {
	}

}
